import React, { useEffect } from "react";
import './App.css';
import Login from "./Login";
import {getTokenFromUrl} from './spotify'
 function App() {
  const [{ token }, dispatch] = useStateValue();

  //Run code in based on a given condition
  useEffect(() => {
    const token = getTokenFromUrl();
    window.location.hash ="";

    const token = hash.access_token;

    if (_token) {
      s.setAccessToken(_token);

      dispatch({
        type: "SET_TOKEN",
        token: _token,
      });
  }, []);
  return (
    <div className="app">
     <Login />
    </div>
  );
}

export default App;
